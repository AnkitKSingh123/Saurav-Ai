import tkinter as tk
root = tk.Tk()
root.title("Tkinter Test")
label = tk.Label(root, text="Tkinter is working!")
label.pack()
root.mainloop()
